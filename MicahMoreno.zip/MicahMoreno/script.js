let eyes = document.getElementById("Eyes");

eyes.addEventListener("click", () => {
    document.getElementById("textbox").innerText = "Ouch!";
});
